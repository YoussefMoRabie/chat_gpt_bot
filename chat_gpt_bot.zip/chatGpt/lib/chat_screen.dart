import 'dart:async';

import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

import 'chatmessage.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {

  final TextEditingController _controller = TextEditingController();
  final List<ChatMessage> _messages = [];
  OpenAI? chatGPT;

  StreamSubscription? _subscription;

  @override
  void dispose(){
    _subscription?.cancel();
    super.dispose();
  }

  void _sendMessage() {
    ChatMessage message = ChatMessage(text: _controller.text, sender: "User");
    setState(() {
      _messages.insert(0, message);
    });
    _controller.clear();

    final request =CompleteText(
        prompt: message.text,
        model: kCodeTranslateModelV2,
        maxTokens: 200);
    _subscription = chatGPT!
        .build(token: "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")
        .onCompleteStream(request: request)
        .listen((response) {
      Vx.log(response!.choices[0].text);

      ChatMessage botMessage = ChatMessage(
          text: response.choices[0].text, sender: "Bot");
      setState(() {
        _messages.insert(0, botMessage);
      });
    });
  }

  Widget _buildTextComposer(){
    return Row(
      children: [
        Expanded( child:
          TextField(
          controller: _controller,
          onSubmitted: (value)=>_sendMessage(),
          decoration:
          const InputDecoration.collapsed(hintText: "Send a message"),

        ),
        ),
        IconButton(
          icon: const Icon(Icons.send),
          onPressed: () => _sendMessage(),
        ),],

    ).px16();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("ChatGPT Demo",textAlign: TextAlign.center,),),
      body: SafeArea(
        child: Column(
          children: [
           Flexible(

              child: ListView.builder(
                  reverse: true,
                  itemCount: _messages.length,
                  padding: Vx.m8,
                  itemBuilder: (context,index) {
                  return _messages[index];
              },
            )),


              Container(
                  decoration: BoxDecoration(
                  color: context.cardColor,
                ),
                child: _buildTextComposer(),
              ),



          ],
        ),
      )
    );
  }
}

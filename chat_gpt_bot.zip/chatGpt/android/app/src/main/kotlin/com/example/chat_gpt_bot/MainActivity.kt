package com.example.chat_gpt_bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
